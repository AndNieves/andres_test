class TestClass:

    def test(self):
        print('What a time to be alive')
