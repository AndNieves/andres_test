def test():
    print('What a time to be alive')